"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ItemCard } from "@/components/item-card"
import { Plus } from "lucide-react"
import { storage } from "@/lib/storage"
import type { Item } from "@/lib/types"

export default function HomePage() {
  const [items, setItems] = useState<Item[]>([])

  useEffect(() => {
    // Load items from localStorage
    setItems(storage.getItems())

    // Listen for updates
    const handleUpdate = () => {
      setItems(storage.getItems())
    }

    window.addEventListener("items-updated", handleUpdate)
    return () => window.removeEventListener("items-updated", handleUpdate)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between px-4">
          <Link href="/" className="text-lg font-semibold">
            Auction
          </Link>
          <Link href="/create">
            <Button size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              List Item
            </Button>
          </Link>
        </div>
      </header>

      <main className="container px-4 py-6">
        <div className="mb-6">
          <h1 className="text-balance text-2xl font-bold">Active Auctions</h1>
          <p className="text-muted-foreground text-sm">Bid on items or list your own</p>
        </div>

        {items.length === 0 ? (
          <div className="flex min-h-[400px] flex-col items-center justify-center gap-4 rounded-lg border border-dashed p-8 text-center">
            <p className="text-muted-foreground">No active auctions yet</p>
            <Link href="/create">
              <Button>Create First Listing</Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
