import { CreateItemForm } from "@/components/create-item-form"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function CreatePage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-2xl px-4 py-6">
        <div className="mb-6">
          <h1 className="text-balance text-2xl font-bold">List an Item</h1>
          <p className="text-muted-foreground text-sm">Create your auction listing</p>
        </div>

        <CreateItemForm />
      </main>
    </div>
  )
}
