"use client"

import { useParams } from "next/navigation"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { LiveItemView } from "@/components/live-item-view"
import { storage } from "@/lib/storage"
import type { Item, Bid } from "@/lib/types"

async function getItem(id: string): Promise<Item | null> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/items/${id}`, {
      cache: "no-store",
    })
    if (!res.ok) return null
    return res.json()
  } catch {
    return null
  }
}

async function getBids(itemId: string): Promise<Bid[]> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/items/${itemId}/bids`, {
      cache: "no-store",
    })
    if (!res.ok) return []
    return res.json()
  } catch {
    return []
  }
}

export default function ItemPage() {
  const params = useParams()
  const id = params.id as string
  const [item, setItem] = useState<Item | null>(null)
  const [bids, setBids] = useState<Bid[]>([])

  useEffect(() => {
    const fetchedItem = storage.getItem(id)
    const fetchedBids = storage
      .getBids(id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

    setItem(fetchedItem)
    setBids(fetchedBids)
  }, [id])

  if (!item) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Item not found</p>
      </div>
    )
  }

  const timeLeft = new Date(item.ends_at).getTime() - Date.now()
  const isEnded = timeLeft <= 0

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center px-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
        </div>
      </header>

      <main className="container max-w-4xl px-4 py-6">
        <LiveItemView initialItem={item} initialBids={bids} />
      </main>
    </div>
  )
}

function TimeRemaining({ endsAt }: { endsAt: string }) {
  const timeLeft = new Date(endsAt).getTime() - Date.now()
  const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24))
  const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60))

  if (timeLeft <= 0) return <span>Ended</span>

  return (
    <span>
      {days > 0 && `${days}d `}
      {hours > 0 && `${hours}h `}
      {minutes}m remaining
    </span>
  )
}
