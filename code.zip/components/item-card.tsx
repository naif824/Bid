import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock } from "lucide-react"
import type { Item } from "@/lib/types"

interface ItemCardProps {
  item: Item
}

export function ItemCard({ item }: ItemCardProps) {
  const timeLeft = new Date(item.ends_at).getTime() - Date.now()
  const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60))
  const minutesLeft = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60))

  return (
    <Link href={`/item/${item.id}`}>
      <Card className="overflow-hidden transition-shadow hover:shadow-lg">
        <div className="relative aspect-video w-full overflow-hidden bg-muted">
          {item.image_url ? (
            <Image src={item.image_url || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center">
              <span className="text-muted-foreground text-sm">No image</span>
            </div>
          )}
        </div>
        <CardContent className="p-4">
          <h3 className="text-balance mb-2 font-semibold leading-tight">{item.title}</h3>
          <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            {item.city}
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold">{item.current_price.toFixed(0)}</span>
            <span className="text-muted-foreground text-sm">SAR</span>
          </div>
        </CardContent>
        <CardFooter className="border-t bg-muted/50 p-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {timeLeft > 0 ? (
              <span>
                {hoursLeft > 0 && `${hoursLeft}h `}
                {minutesLeft}m left
              </span>
            ) : (
              <Badge variant="secondary" className="text-xs">
                Ended
              </Badge>
            )}
          </div>
        </CardFooter>
      </Card>
    </Link>
  )
}
