"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import { storage } from "@/lib/storage"
import type { Bid } from "@/lib/types"

interface BidFormProps {
  itemId: string
  currentPrice: number
}

export function BidForm({ itemId, currentPrice }: BidFormProps) {
  const [loading, setLoading] = useState(false)
  const [bidderName, setBidderName] = useState("")
  const [amount, setAmount] = useState("")
  const [error, setError] = useState("")

  const minIncrement = Math.max(Math.ceil(currentPrice * 0.01), 5)
  const minBid = currentPrice + minIncrement

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const bidAmount = Number.parseFloat(amount)

      if (bidAmount < minBid) {
        throw new Error(`Bid must be at least ${minBid} SAR`)
      }

      const newBid: Bid = {
        id: crypto.randomUUID(),
        item_id: itemId,
        bidder_name: bidderName,
        amount: bidAmount,
        created_at: new Date().toISOString(),
      }

      storage.saveBid(newBid)
      storage.updateItem(itemId, { current_price: bidAmount })

      setAmount("")
      setError("")
    } catch (error: any) {
      setError(error.message || "Failed to place bid")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-lg border p-4">
      <h3 className="font-semibold">Place a Bid</h3>

      {error && <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

      <div className="space-y-2">
        <Label htmlFor="bidder_name">Your Name *</Label>
        <Input
          id="bidder_name"
          required
          value={bidderName}
          onChange={(e) => setBidderName(e.target.value)}
          placeholder="Mohammed"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Bid Amount (SAR) *</Label>
        <Input
          id="amount"
          type="number"
          required
          min={minBid}
          step="1"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder={minBid.toString()}
        />
        <p className="text-xs text-muted-foreground">
          Minimum bid: {minBid.toFixed(0)} SAR (current + {minIncrement} SAR)
        </p>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Placing Bid...
          </>
        ) : (
          "Place Bid"
        )}
      </Button>
    </form>
  )
}
