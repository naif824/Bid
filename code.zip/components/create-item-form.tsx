"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SAUDI_CITIES } from "@/lib/types"
import { Upload, Loader2 } from "lucide-react"
import Image from "next/image"
import { storage } from "@/lib/storage"
import type { Item } from "@/lib/types"

export function CreateItemForm() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    city: "",
    starting_price: "",
    seller_name: "",
    duration: "24",
  })

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const endsAt = new Date()
      endsAt.setHours(endsAt.getHours() + Number.parseInt(formData.duration))

      const newItem: Item = {
        id: crypto.randomUUID(),
        title: formData.title,
        description: formData.description,
        image_url: imagePreview, // Use base64 image
        city: formData.city,
        starting_price: Number.parseFloat(formData.starting_price),
        current_price: Number.parseFloat(formData.starting_price),
        seller_name: formData.seller_name,
        ends_at: endsAt.toISOString(),
        created_at: new Date().toISOString(),
      }

      storage.saveItem(newItem)
      router.push(`/item/${newItem.id}`)
    } catch (error) {
      console.error("[v0] Submit error:", error)
      alert("Failed to create listing. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="image">Image</Label>
        <div className="flex flex-col gap-4">
          {imagePreview && (
            <div className="relative aspect-video w-full overflow-hidden rounded-lg border">
              <Image src={imagePreview || "/placeholder.svg"} alt="Preview" fill className="object-cover" />
            </div>
          )}
          <label
            htmlFor="image"
            className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed p-8 transition-colors hover:bg-muted"
          >
            <Upload className="h-5 w-5 text-muted-foreground" />
            <span className="text-muted-foreground text-sm">{imagePreview ? "Change image" : "Upload image"}</span>
            <input id="image" type="file" accept="image/*" onChange={handleImageChange} className="sr-only" />
          </label>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Title *</Label>
        <Input
          id="title"
          required
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="e.g., iPhone 15 Pro Max"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Describe your item..."
          rows={4}
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="city">City *</Label>
          <Select required value={formData.city} onValueChange={(value) => setFormData({ ...formData, city: value })}>
            <SelectTrigger id="city">
              <SelectValue placeholder="Select city" />
            </SelectTrigger>
            <SelectContent>
              {SAUDI_CITIES.map((city) => (
                <SelectItem key={city} value={city}>
                  {city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="starting_price">Starting Price (SAR) *</Label>
          <Input
            id="starting_price"
            type="number"
            required
            min="1"
            step="0.01"
            value={formData.starting_price}
            onChange={(e) => setFormData({ ...formData, starting_price: e.target.value })}
            placeholder="100"
          />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="seller_name">Your Name *</Label>
          <Input
            id="seller_name"
            required
            value={formData.seller_name}
            onChange={(e) => setFormData({ ...formData, seller_name: e.target.value })}
            placeholder="Ahmed"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Duration *</Label>
          <Select
            required
            value={formData.duration}
            onValueChange={(value) => setFormData({ ...formData, duration: value })}
          >
            <SelectTrigger id="duration">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 hour</SelectItem>
              <SelectItem value="6">6 hours</SelectItem>
              <SelectItem value="12">12 hours</SelectItem>
              <SelectItem value="24">24 hours</SelectItem>
              <SelectItem value="48">48 hours</SelectItem>
              <SelectItem value="72">3 days</SelectItem>
              <SelectItem value="168">7 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Creating...
          </>
        ) : (
          "Create Listing"
        )}
      </Button>
    </form>
  )
}
