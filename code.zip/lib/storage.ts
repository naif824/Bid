import type { Item, Bid } from "./types"

const ITEMS_KEY = "auction_items"
const BIDS_KEY = "auction_bids"

export const storage = {
  // Items
  getItems(): Item[] {
    if (typeof window === "undefined") return []
    const items = localStorage.getItem(ITEMS_KEY)
    return items ? JSON.parse(items) : []
  },

  getItem(id: string): Item | null {
    const items = this.getItems()
    return items.find((item) => item.id === id) || null
  },

  saveItem(item: Item): void {
    const items = this.getItems()
    items.push(item)
    localStorage.setItem(ITEMS_KEY, JSON.stringify(items))
    window.dispatchEvent(new CustomEvent("items-updated"))
  },

  updateItem(id: string, updates: Partial<Item>): void {
    const items = this.getItems()
    const index = items.findIndex((item) => item.id === id)
    if (index !== -1) {
      items[index] = { ...items[index], ...updates }
      localStorage.setItem(ITEMS_KEY, JSON.stringify(items))
      window.dispatchEvent(new CustomEvent("items-updated"))
    }
  },

  // Bids
  getBids(itemId: string): Bid[] {
    if (typeof window === "undefined") return []
    const bids = localStorage.getItem(BIDS_KEY)
    const allBids: Bid[] = bids ? JSON.parse(bids) : []
    return allBids.filter((bid) => bid.item_id === itemId)
  },

  saveBid(bid: Bid): void {
    const bids = localStorage.getItem(BIDS_KEY)
    const allBids: Bid[] = bids ? JSON.parse(bids) : []
    allBids.push(bid)
    localStorage.setItem(BIDS_KEY, JSON.stringify(allBids))
    window.dispatchEvent(new CustomEvent("bids-updated", { detail: { itemId: bid.item_id } }))
  },
}
