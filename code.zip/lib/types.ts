export interface Item {
  id: string
  title: string
  description: string | null
  image_url: string | null
  city: string
  starting_price: number
  current_price: number
  seller_name: string
  created_at: string
  ends_at: string
}

export interface Bid {
  id: string
  item_id: string
  bidder_name: string
  amount: number
  created_at: string
}

export const SAUDI_CITIES = [
  "Riyadh",
  "Jeddah",
  "Mecca",
  "Medina",
  "Dammam",
  "Khobar",
  "Dhahran",
  "Taif",
  "Buraidah",
  "Tabuk",
  "Khamis Mushait",
  "Hail",
  "Najran",
  "Abha",
  "Yanbu",
  "Al Kharj",
  "Jubail",
  "Al Qatif",
]
